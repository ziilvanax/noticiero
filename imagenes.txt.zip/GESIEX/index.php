<!DOCTYPE html>
<html>
<head>
	<?php session_start(); ?>
<meta http-equiv="refresh" content="0;url=pages/index.html">
<title>Sistema POI - PAC</title>
<script language="javascript">
    window.location.href = "pages/index.php"
</script>
</head>
<body>
	Go to <a href="pages/index.php">/pages/index.php</a>
</body>
</html>