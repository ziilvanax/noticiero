<!DOCTYPE html>
<html lang="en">

<head>
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

   <title>Gestión de la Información Externa</title>
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <script language='javascript'>
      function valida_envia(){ 
      alert('Los datos se han guardado correctamente'); 
      document.ingresar.submit(); 
      } 

      function valida_envia2(){
        alert('Los datos se han guardado correctamente');
        document.ingresar2.submit(); 
      }

      function valida_envia3(){
        alert('Los datos se han guardado correctamente');
        document.ingresar3.submit();
      }

      function valida_envia4(){
        alert('Los datos se han guardado correctamente')
        document.ingresar4.submit();
      }

      function valida_envia5()
      {
        alert('Los datos se han guardado correctamente')
        document.ingresar5.submit();
      }
    </script>

</head>

 <?php 
  include_once("conexion.php"); 
    error_reporting(E_ALL ^ E_NOTICE);

      $nombres=$_POST['nombres'];
      $apellidos=$_POST['apellidos'];
      $dni=$_POST['dni'];
      $alias=$_POST['alias'];
      $organizacion=$_POST['organizacion'];
      $edad=$_POST['edad'];
      $na=$_POST['nacionalidad'];
      $tipo_infractor=$_POST['tipo_infractor'];

    switch ($na) {
    case Perú:
        $nacionalidad = 1; 
        break;
    case Chile:
        $nacionalidad = 2; 
        break;
    case Colombia:
        $nacionalidad = 3; 
        break;
    case Venezuela:
        $nacionalidad = 4; 
        break;
    case Bolivia:
        $nacionalidad = 5; 
        break;
    case Ecuador:
        $nacionalidad = 6; 
        break;
    case Argentina:
        $nacionalidad = 7; 
        break;
// AQUI ME QUEDEEEEEE, 





        
                       
}

  $query1 = " SELECT  id_tipoin FROM tipo_infractor WHERE tipo_infractor.nombre = '".$tipo_infractor."'";

  $result=$conexion->query($query1); 

   $query = "INSERT INTO persona VALUES (NULL, '".$nombres."', '".$apellidos."', '".$alias."', '".$edad."', '".$nacionalidad."', '".$organizacion."', '".$dni."', '".$query1."')";
   //  $query1= "call i_persona($id_persona, $nombres, $apellidos, $alias, $edad, $nacionalidad, $organizacion)";
     $result=$conexion->query($query); 
?> 

<?php 
      error_reporting(E_ALL ^ E_NOTICE);
     $nom_empresa=$_POST['nom_empresa'];
     //$nacionalidad=$_POST[''];
     $nacionalidad=2;
     $rubro=$_POST['rubro'];
     $ruc=$_POST['ruc'];

     $query = "INSERT INTO empresa VALUES (NULL, '".$nom_empresa."', '".$nacionalidad."', '".$rubro."', '".$ruc."')";

     $result=$conexion->query($query); 

?>
<?php 
      error_reporting(E_ALL ^ E_NOTICE);
    // $item=$_POST['item'];
      $item=5;
     $cantidad=$_POST['cantidad'];
     //$unidad=$_POST['unidad'];
     $unidad=1;
    // $id_moneda=$_POST['id_moneda'];
     $id_moneda=2;
     $valor=$_POST['valor'];

     $query = "INSERT INTO mercancia VALUES (NULL, '".$item."', '".$cantidad."', '".$unidad."', '".$id_moneda."', '".$valor."')";

     $result=$conexion->query($query); 

?>
<?php 
      error_reporting(E_ALL ^ E_NOTICE);
   
    //$tipo_vehiculo=$_POST['tipo_vehiculo'];
    $tipo_vehiculo=2;
    //$marca =$_POST['marca'];
    $marca=2;
    $placa=$_POST['placa'];
    $caracteristicas=$_POST['caracteristicas'];

     $query = "INSERT INTO vehiculo VALUES (NULL, '".$tipo_vehiculo."', '".$marca."', '".$placa."', '".$caracteristicas."')";

     $result=$conexion->query($query); 
?>
<?php 
    error_reporting(E_ALL ^ E_NOTICE);
    $fecha=$_POST['fecha'];
    //$lugar=$_POST['lugar'];
    $lugar=1;
    $titulo=$_POST['titulo'];
    $resumen=$_POST['resumen'];
    $delito=3;
    //$delito=$_POST['delito'];
   
    //$interventor=$_POST['interventor'];
  ;
    $query = "INSERT INTO intervencion VALUES (NULL, '".$fecha."', '".$lugar."', '".$titulo."', '".$resumen."')";
   $result=$conexion->query($query);

 

     //$query1= "call i_persona($id_persona, $nombres, $apellidos, $alias, $edad, $nacionalidad, $organizacion)";
?>

<body>
  <div id="wrapper">
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand text-center" href="index.php"> GESIEX - Gestión de la Información Externa</a>
         </div>
         <ul class="nav navbar-nav navbar-center">
            <li class="hidden">
               <a href="#page-top"></a>
            </li>     
            <li>
               <a class="page-scroll" href="index.php"><i class="fa fa-fw fa-home"></i> Home</a>
            </li>
            <li class="">
               <a href="index.php" class="page-scroll" >Noticias ADUANA </a>  
            </li>
            <li class="">
               <a href="index2.php" class="page-scroll">Noticias SUNAT</a>     
            </li>    
         </ul>
         <ul class="nav navbar-top-links navbar-right">
            <li class="dropdown">
               <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
               </a>
               <ul class="dropdown-menu dropdown-user">
                  <li><a href="#"><i class="fa fa-user fa-fw"></i>admin</a>
                  </li>     
                  <li class="divider"></li>
                  <li><a href="../../login.php"><i class="fa fa-sign-out fa-fw"></i> Cerrar Sesión</a>
                  </li>
               </ul>
            </li>
         </ul>

         <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
               <ul class="nav" id="side-menu">
                  <li class="sidebar-search">
                     <div class="input-group custom-search-form">
                        <img  class="img-responsive text-center" src="img/logoblanco.png" width="110" height="100" alt="">
                           <h5>Intendencia de Aduana de Tacna</h5>
                     </div>
                  </li>
                  <li>
                     <a class="navbar-default" href="ingresar.php"><i class="fa fa-edit fa-fw"></i> Ingresar Noticia</a>
                  </li>
                  <li>
                     <a class="navbar-default" href="#"><i class="fa fa-folder-open-o fa-fw"></i> Noticias <span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level">
                        <li>
                           <a class="navbar-default" href="not_fecha.php">Por Fecha</a>
                        </li>
                        <li>
                           <a class="navbar-default" href="not_del.php">Por Delito</a>
                        </li>
                        <li>
                           <a class="navbar-default" href="not_lugar.php">Por Lugar</a>
                        </li>
                        <li>
                           <a class="navbar-default" href="not_interventor.php">Por Interventor</a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a class="navbar-default" href="#"><i class="fa fa-users fa-fw"></i> Infractores <span class="fa arrow"></span></a>    
                     <ul class="nav nav-second-level">
                           <li>
                              <a class="navbar-default" href="inf_del.php">Por Delito</a>
                           </li>
                           <li>
                              <a class="navbar-default" href="inf_lugar.php">Por Lugar</a>
                           </li>
                     </ul>
                  </li>
                  <li>
                     <a class="navbar-default" href="programacion.php"><i class="fa fa-calendar fa-fw"></i> Programación Trimestral </a>      
                  </li>
               </ul>
            </div>
         </div>
    </nav>

    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h2 class="page-header">Registro de Noticia</h2>
          </div>
        </div>   
    
          <div class="row">
            <form role="form" method="POST" action="ingresar.php" id="ingresar5" name="ingresar5">
              <div class="col-lg-7">
                <div class="panel panel-success">
                  <div class="panel-heading">Intervención</div>
                  <div class="panel-body">
                   
                      <div class="form-group">
                          <label>Título</label>
                          <input name="titulo" id="titulo" class="form-control">
                          <p class="help-block"></p>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Fecha</label>
                           <input name="fecha" id="fecha" class="form-control" placeholder="AAAA-MM-DD" >
                            <p class="help-block"></p>
                          </div>
                        </div>
                        <div class="col-md-6"> 
                          <div class="form-group">
                            <label>Lugar</label>
                            <select name="lugar" id="lugar" class="form-control">
                             <?php 
                                $lugar=array();
                                $query = "call m_lugar()";
                                $result = $conexion->query($query);
                                while($row = mysqli_fetch_row($result))
                                {
                                    $lugar[] = $row;
                                }

                                mysqli_free_result($result);
                                $conexion->next_result();
                                
                                for ($i=0;$i<count($lugar);$i++)
                                {
                                    echo 
                                    "
                                      <option>".utf8_decode($lugar[$i][0])."</option>
                                    ";
                                    
                                }

                                                         
                                                         
                              ?>
                             
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                          <div class="col-md-6">  
                              <div class="form-group">
                                <label>Delito</label>
                                <select  name="delito" id="delito" class="form-control">
                                <?php
                                  $delito=array();
                                  $query = "call m_delito()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $delito[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($delito);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($delito[$i][0])."</option>
                                      ";
                                      
                                  }
                           
                              ?>
                                </select>
                              </div>
                          </div>
                          <div class="col-md-6">  
                              <div class="form-group" >
                                <label>Interventor</label>
                                <select name="interventor" id="interventor" class="form-control">
                                 <?php
                                  $interventor=array();
                                  $query = "call m_interventor()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $interventor[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($interventor);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($interventor[$i][0])."</option>
                                      ";
                                      
                                  }

                                 ?>
                                </select>
                              </div>
                          </div>
                      </div>                  
                      <div class="form-group">
                        <label>Resumen</label>
                        <textarea name="resumen" id="resumen" class="form-control" rows="3"></textarea>
                      </div>    
                      <div class="row">
                        <div class="col-md-4"> 
                          <div class="form-group">
                            <label>Fuente</label>
                            <select name="fuente" id="fuente" class="form-control">
                              <?php
                                $fuente=array();
                                  $query = "call m_diario()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $fuente[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($fuente);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($fuente[$i][0])."</option>
                                      ";   
                                  }
                              ?>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="form-group">
                            <label>Página</label>
                            <input name="pagina" id="pagina" class="form-control">
                            <p class="help-block"></p>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Link</label>
                            <input name="link" id="link" class="form-control">
                            <p class="help-block"></p>
                          </div>
                        </div>
                      </div>
                      <label>Infractor</label>
                      <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Nombres</th>
                                            <th>Apellidos</th>
                                            <th>Edad </th>
                                            <th>Tipo infractor</th>
                                            <th>Nacionalidad</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Mark</td>
                                            <td>Otto</td>
                                            <td>36</td>
                                            <td>Conductor</td>
                                            <td>Perú</td>
                                        </tr>
                                    </tbody>
                                </table>
                      </div> 
                      <label>Mercancía</label>
                      <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Item</th>
                                            <th>Cantidad</th>
                                            <th>Unidad </th>
                                            <th>Valor</th>
                                            <th>Moneda</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Marihuana</td>
                                            <td>13</td>
                                            <td>Kg</td>
                                            <td>6000.00</td>
                                            <td>Soles</td>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                      </div>
                      <label>Vehículo</label>
                      <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Tipo</th>
                                            <th>Marca</th>
                                            <th>Placa</th>
                                            <th>Características</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Camioneta</td>
                                            <td>Toyota</td>
                                            <td>PCQ-345</td>
                                            <td>Rojo</td>
                                        </tr>
                                    </tbody>
                                </table>
                      </div>
                      <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-4 text-center">
                          
                          <input name="Enviar" class="btn btn-info btn-md" type="button" id="Enviar" value="Guardar" onClick="valida_envia5()"/> 
                        </div>
                        <div class="col-md-4"></div>
                        <br> <br>
                      </div>
                  </div>
                </div>
              </div>
            </form>
              
              <div class="col-lg-5">
             
                <form role="form" method="POST" action="ingresar.php" id="ingresar" name="ingresar">
                <div class="panel-group">
                  <div class="panel panel-success">
                    <div class="panel-heading">
                      <h4 class="panel-title">
                        <a data-toggle="collapse" href="#collapse1">Agregar Infractor - Persona</a>
                      </h4>
                    </div>
                    <div id="collapse1" class="panel-collapse collapse">
                      <div class="panel-body">
                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label>Nombres</label>
                                <input id="nombres" name="nombres" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                            <div class="col-md-6"> 
                              <div class="form-group">
                                <label>Apellidos</label>
                                <input id="apellidos"  name="apellidos" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                          </div>
                          
                          <div class="row">
                            <div class="col-md-4">
                              <div class="form-group">
                                <label>DNI</label>
                                <input id="dni" name="dni" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                            <div class="col-md-4"> 
                              <div class="form-group">
                                <label>Alias</label>
                                <input id="alias" name="alias" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                            <div class="col-md-4"> 
                              <div class="form-group">
                                <label>Organizacion</label>
                                <input id="organizacion" name="organizacion" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                          </div> 

                          <div class="row">
                              <div class="col-md-4">  
                                <div class="form-group">
                                  <label>Edad</label>
                                  <input id="edad" name="edad" class="form-control">
                                  <p class="help-block"></p>
                                </div>
                              </div>
                              <div class="col-md-4">  
                                  <div class="form-group">
                                <label>Tipo Infractor</label>
                                <select id="tipo_infractor" name="tipo_infractor" class="form-control">
                                <?php
                                  $tipo_infractor=array();
                                  $query = "call m_tinfractor()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $tipo_infractor[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($tipo_infractor);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($tipo_infractor[$i][0])."</option>
                                      ";
                                      
                                  }
                                  
                                ?>
                                </select>
                              </div>
                              </div>
                              <div class="col-md-4">  
                                  <div class="form-group">
                                <label>Nacionalidad</label>
                                <select id="nacionalidad" name="nacionalidad" class="form-control">
                                  <?php
                                    $nacionalidad=array();
                                  $query = "call m_nacionalidad()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $nacionalidad[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($nacionalidad);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($nacionalidad[$i][0])."</option>
                                      ";
                                      
                                  }

                                  ?>
                                </select>
                              </div>
                              </div>
                          </div>    
                             <input name="Enviar" class="btn btn-info btn-md" type="button" id="Enviar" value="Guardar" onClick="valida_envia()"/>           
                      </div>
                      
                    </div>
                  </div>
                </div>
              </form>
              <form role="form" method="POST" action="ingresar.php" id="ingresar2" name="ingresar2">
                <div class="panel-group">
                  <div class="panel panel-success">
                    <div class="panel-heading">
                      <h4 class="panel-title">
                        <a data-toggle="collapse" href="#collapse4">Agregar Infractor - Empresa</a>
                      </h4>
                    </div>
                    <div id="collapse4" class="panel-collapse collapse">
                      <div class="panel-body">
                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label>Razon Social</label>
                                <input name="nom_empresa" id="nom_empresa" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                            <div class="col-md-6"> 
                              <div class="form-group">
                                <label>Ruc</label>
                                <input class="form-control" name="ruc" id="ruc">
                                <p class="help-block"></p>
                              </div>
                            </div>
                          </div>
                          
                          <div class="row">
                              <div class="col-md-6">  
                                <div class="form-group">
                                  <label>Rubro</label>
                                  <input name="rubro" id="rubro" class="form-control">
                                  <p class="help-block"></p>
                                </div>
                              </div>
                                <div class="col-md-6">  
                                  <div class="form-group">
                                <label>Nacionalidad</label>
                                <select name="nacionalidad" id="nacionalidad" class="form-control">
                                 <?php
                                    $nacionalidad=array();
                                  $query = "call m_nacionalidad()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $nacionalidad[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($nacionalidad);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($nacionalidad[$i][0])."</option>
                                      ";
                                      
                                  }
                                  ?>
                                </select>
                              </div>
                              </div>
                          </div> 
                            <input name="Enviar2" class="btn btn-info btn-md" type="button" id="Enviar2" value="Guardar" onClick="valida_envia2()"/>                
                      </div>
                      
                    </div>
                  </div>
                </div>
              </form>
              <form role="form" method="POST" action="ingresar.php" id="ingresar3" name="ingresar3">
                <div class="panel-group">
                  <div class="panel panel-success">
                    <div class="panel-heading">
                      <h4 class="panel-title">
                        <a data-toggle="collapse" href="#collapse2">Agregar Mercancía</a>
                      </h4>
                    </div>
                    <div id="collapse2" class="panel-collapse collapse">
                      <div class="panel-body">
                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label>Item</label>
                                <select name="item" id="item" class="form-control">
                                  <?php
                                    $item=array();
                                  $query = "call m_item()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $item[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($item);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($item[$i][0])."</option>
                                      ";
                                      
                                  }

                                  ?>
                                </select>
                              </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                  <label>Cantidad</label>
                                  <input  name="cantidad" id="cantidad" class="form-control">
                                  <p class="help-block"></p>
                                </div>
                            </div>
                            <div class="col-md-3"> 
                              <div class="form-group">
                                <label>Unidad</label>
                                <select name="unidad" id="unidad" class="form-control">
                                  <?php
                                  $unidad=array();
                                  $query = "call m_unidad()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $unidad[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($unidad);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($unidad[$i][0])."</option>
                                      ";
                                      
                                  }
                                  ?>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                              <div class="col-md-6">  
                                  <div class="form-group">
                                    <label>Valor</label>
                                    <input name="valor" id="valor" class="form-control">
                                  <p class="help-block"></p>
                                  </div>
                              </div>
                              <div class="col-md-6">  
                                  <div class="form-group" >
                                    <label>Moneda</label>
                                    <select name="id_moneda" id="id_moneda" class="form-control">
                                      <?php
                                  $moneda=array();
                                  $query = "call m_moneda()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $moneda[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($moneda);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($moneda[$i][0])."</option>
                                      ";
                                      
                                  }

                                  ?>
                                    </select>
                                  </div>
                              </div>  
                          </div> 
                            <input name="Enviar3" class="btn btn-info btn-md" type="button" id="Enviar3" value="Guardar" onClick="valida_envia3()"/>                
                      </div>
                      
                    </div>
                  </div>
                </div>
              </form>
              <form role="form" method="POST" action="ingresar.php" id="ingresar4" name="ingresar4">
                <div class="panel-group">
                  <div class="panel panel-success">
                    <div class="panel-heading">
                      <h4 class="panel-title">
                        <a data-toggle="collapse" href="#collapse3">Agregar Vehículo</a>
                      </h4>
                    </div>
                    <div id="collapse3" class="panel-collapse collapse">
                      <div class="panel-body">
                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label>Tipo</label>
                                <select name="tipo_vehiculo" id="tipo_vehiculo" class="form-control">
                                  <?php
                                  $t_vehiculo=array();
                                  $query = "call m_tvehiculo()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $t_vehiculo[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($t_vehiculo);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($t_vehiculo[$i][0])."</option>
                                      ";
                
                                  }
                                  ?>
                                </select>
                                <p class="help-block"></p>
                              </div>
                            </div>
                            <div class="col-md-6"> 
                              <div class="form-group">
                                <label>Marca</label>
                                <select name="marca" id="marca" class="form-control">
                                  <?php
                                  $marca=array();
                                  $query = "call m_marca()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $marca[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($marca);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($marca[$i][0])."</option>
                                      ";
                                      
                                  }

                                  $conexion->close();
                                  ?>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                              <div class="col-md-6">  
                                  <div class="form-group">
                                    <label>Placa</label>
                                    <input name="placa" id="placa" class="form-control" placeholder="AAA-000" >
                                  </div>
                              </div>
                              <div class="col-md-6">  
                                  <div class="form-group" >
                                    <label>Características</label>
                                    <input name="caracteristicas" id="caracteristicas" class="form-control">
                                  </div>
                              </div>
                          </div> 
                         <input name="Enviar4" class="btn btn-info btn-md" type="button" id="Enviar4" value="Guardar" onClick="valida_envia4()"/>                     
                      </div>
                    </div>
                  </div>
                </div>
              </form>
              </div>
          </div>
        
        <br>
    </div>   
  </div>
  <script src="../bower_components/jquery/dist/jquery.min.js"></script>
  <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>
  <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
