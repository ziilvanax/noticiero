<?php 
	include_once("conexion.php"); 
    error_reporting(E_ALL ^ E_NOTICE);
   		
   		//$id=$_POST['id'];
     	$nombre=$_POST['nombre'];
   
     	$edad=$_POST['edad'];
     	

     if ( !$nombre  ) 
     	{
     		echo "<br>";
			echo "<center>No has introducido todos los detalles requeridos.<br>"."Por favor vuelve intentarlo de nuevo.<center>";
			echo "<br>";
			echo "<center><a href=\"prueba2.php\">Retornar</a></center>";
			exit;
     	}
     	
     	$query = "INSERT INTO prueba VALUES (NULL, '".$nombre."', '".$edad."')";
			 $result=$conexion->query($query); 
			if($result)
			
				echo "<br>";
				echo "<center>La peticion se realizo con exito</center>";
				echo "<br>";
				echo "<center><a href=\"prueba2.php\">Retornar</a></center>";

				
?>
 