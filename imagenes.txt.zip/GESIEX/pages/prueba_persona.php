<!DOCTYPE html>
<html lang="en">
<head>
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

   <title>Gestión de la Información Externa</title>
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>


<?php 
  include_once("conexion.php"); 
    error_reporting(E_ALL ^ E_NOTICE);
    $id_persona = 0;
if (isset($_POST['nombres'], $_POST['apellidos'], $_POST['dni'], $_POST['alias'], $_POST['organizacion'], $_POST['edad']) and $_POST["nombres"] !="" and $_POST["apellidos"]!="" and $_POST["dni"]!="" and $_POST['alias']!="" and $_POST['organizacion']!="" and $_POST['edad'])


     {
      $nombres=$_POST['nombres'];
      $apellidos=$_POST['apellidos'];
      $dni=$_POST['dni'];
      $alias=$_POST['alias'];
      $organizacion=$_POST['organizacion'];
      $edad=$_POST['edad'];
      $nacionalidad=1;
      $id_persona=$id_persona +1;

     }  
    
     $query1= "call i_persona($id_persona, $nombres, $apellidos, $alias, $edad, $nacionalidad, $organizacion)";
     $result=$conexion->query($query1); 
  echo $_POST['nombres'];
echo $_REQUEST['nombres'];
?>

<body>
  <div id="wrapper">
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand text-center" href="index.php"> GESIEX - Gestión de la Información Externa</a>
         </div>
         <ul class="nav navbar-nav navbar-center">
            <li class="hidden">
               <a href="#page-top"></a>
            </li>     
            <li>
               <a class="page-scroll" href="index.php"><i class="fa fa-fw fa-home"></i> Home</a>
            </li>
            <li class="">
               <a href="index.php" class="page-scroll" >Noticias ADUANA </a>  
            </li>
            <li class="">
               <a href="index2.php" class="page-scroll">Noticias SUNAT</a>     
            </li>    
         </ul>
         <ul class="nav navbar-top-links navbar-right">
            <li class="dropdown">
               <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
               </a>
               <ul class="dropdown-menu dropdown-user">
                  <li><a href="#"><i class="fa fa-user fa-fw"></i>admin</a>
                  </li>     
                  <li class="divider"></li>
                  <li><a href="../../login.php"><i class="fa fa-sign-out fa-fw"></i> Cerrar Sesión</a>
                  </li>
               </ul>
            </li>
         </ul>

         <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
               <ul class="nav" id="side-menu">
                  <li class="sidebar-search">
                     <div class="input-group custom-search-form">
                        <img  class="img-responsive text-center" src="img/logoblanco.png" width="110" height="100" alt="">
                           <h5>Intendencia de Aduana de Tacna</h5>
                     </div>
                  </li>
                  <li>
                     <a class="navbar-default" href="ingresar.php"><i class="fa fa-edit fa-fw"></i> Ingresar Noticia</a>
                  </li>
                  <li>
                     <a class="navbar-default" href="#"><i class="fa fa-folder-open-o fa-fw"></i> Noticias <span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level">
                        <li>
                           <a class="navbar-default" href="not_fecha.php">Por Fecha</a>
                        </li>
                        <li>
                           <a class="navbar-default" href="not_del.php">Por Delito</a>
                        </li>
                        <li>
                           <a class="navbar-default" href="not_lugar.php">Por Lugar</a>
                        </li>
                        <li>
                           <a class="navbar-default" href="not_interventor.php">Por Interventor</a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a class="navbar-default" href="#"><i class="fa fa-users fa-fw"></i> Infractores <span class="fa arrow"></span></a>    
                     <ul class="nav nav-second-level">
                           <li>
                              <a class="navbar-default" href="inf_del.php">Por Delito</a>
                           </li>
                           <li>
                              <a class="navbar-default" href="inf_lugar.php">Por Lugar</a>
                           </li>
                     </ul>
                  </li>
                  <li>
                     <a class="navbar-default" href="programacion.php"><i class="fa fa-calendar fa-fw"></i> Programación Trimestral </a>      
                  </li>
               </ul>
            </div>
         </div>
    </nav>

    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h2 class="page-header">Registro de Noticia</h2>
          </div>
        </div>   
        <form role="form" method="POST" action="prueba_persona.php">
          <div class="row">
              <div class="col-lg-7">
                
              </div>
              <div class="col-lg-5">
                <div class="panel-group">
                  <div class="panel panel-success">
                    <div class="panel-heading">
                      <h4 class="panel-title">
                        <a data-toggle="collapse" href="#collapse1">Agregar Infractor - Persona</a>
                      </h4>
                    </div>
                    <div id="collapse1" class="panel-collapse collapse">
                      <div class="panel-body">
                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label>Nombres</label>
                                <input id="nombres" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                            <div class="col-md-6"> 
                              <div class="form-group">
                                <label>Apellidos</label>
                                <input id="apellidos" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                          </div>
                          
                          <div class="row">
                            <div class="col-md-4">
                              <div class="form-group">
                                <label>DNI</label>
                                <input id="dni" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                            <div class="col-md-4"> 
                              <div class="form-group">
                                <label>Alias</label>
                                <input id="alias" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                            <div class="col-md-4"> 
                              <div class="form-group">
                                <label>Organizacion</label>
                                <input id="organizacion" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                          </div> 

                          <div class="row">
                              <div class="col-md-4">  
                                <div class="form-group">
                                  <label>Edad</label>
                                  <input id="edad" class="form-control">
                                  <p class="help-block"></p>
                                </div>
                              </div>
                              <div class="col-md-4">  
                                  <div class="form-group">
                                <label>Tipo Infractor</label>
                                <select id="" class="form-control">
                                  <?php
                                    $tipo_infractor=array();
                                  $query = "call m_tinfractor()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $tipo_infractor[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($tipo_infractor);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($tipo_infractor[$i][0])."</option>
                                      ";
                                      
                                  }
                                  
                                  ?>
                                </select>
                              </div>
                              </div>
                              <div class="col-md-4">  
                                  <div class="form-group">
                                <label>Nacionalidad</label>
                                <select id="" class="form-control">
                                  <?php
                                    $nacionalidad=array();
                                  $query = "call m_nacionalidad()";
                                  $result = $conexion->query($query);
                                  while($row = mysqli_fetch_row($result))
                                  {
                                      $nacionalidad[] = $row;
                                  }

                                  mysqli_free_result($result);
                                  $conexion->next_result();
                                  
                                  for ($i=0;$i<count($nacionalidad);$i++)
                                  {
                                      echo 
                                      "
                                        <option>".($nacionalidad[$i][0])."</option>
                                      ";
                                      
                                  }

                                  ?>
                                </select>
                              </div>
                              </div>
                          </div> 
                            <button type="submit" class="btn btn-info btn-md">Agregar</button>
                            <input type="submit" name="submit" class="btn btn-primary" value="Agregar">               
                      </div>
                      
                    </div>
                  </div>
                </div>
                

              </div>
          </div>
        </form>
        <br>
    </div>   
  </div>
  <script src="../bower_components/jquery/dist/jquery.min.js"></script>
  <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>
  <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
